#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "$(readlink -f -- "$0")")"

echo "=== Assistente local de consulta própria de CPF ==="
command -v python3 >/dev/null 2>&1 || {
  echo "ERRO: Python 3 não encontrado. Instale-o pelo gerenciador oficial do seu sistema." >&2
  exit 1
}

python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("ERRO: é necessário Python 3.10 ou superior.")
print(f"Python {sys.version.split()[0]} detectado.")
PY

# Nenhuma dependência externa é necessária; não há instalação automática com privilégios.
umask 077
exec python3 ./consulta_cpf.py "$@"
