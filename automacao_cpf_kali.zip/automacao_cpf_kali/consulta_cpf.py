#!/usr/bin/env python3
"""Assistente local para validar um CPF e orientar consultas oficiais do próprio titular.

Não consulta bases privadas, não faz scraping de dados pessoais e não envia o CPF pela rede.
"""
from __future__ import annotations

import argparse
import datetime as dt
import getpass
import json
import logging
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

APP_DIR = Path(__file__).resolve().parent
LOG_FILE = APP_DIR / "execucao.log"
REPORT_DIR = APP_DIR / "relatorios"

OFFICIAL_SOURCES = [
    {
        "name": "Receita Federal — serviços de CPF",
        "url": "https://www.gov.br/receitafederal/pt-br/assuntos/meu-cpf",
        "purpose": "Orientações e serviços oficiais relacionados ao CPF.",
    },
    {
        "name": "Portal Gov.br",
        "url": "https://www.gov.br/",
        "purpose": "Acesso aos serviços públicos digitais com autenticação própria.",
    },
    {
        "name": "Banco Central — Registrato",
        "url": "https://registrato.bcb.gov.br/",
        "purpose": "Consultar relatórios financeiros próprios após autenticação oficial.",
    },
    {
        "name": "Meu INSS",
        "url": "https://meu.inss.gov.br/",
        "purpose": "Consultar serviços e informações previdenciárias próprias.",
    },
]

def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, encoding="utf-8"),
            logging.StreamHandler(sys.stderr),
        ],
    )

def normalize_cpf(raw: str) -> str:
    digits = re.sub(r"\D", "", raw)
    if len(digits) != 11:
        raise ValueError("O CPF deve conter exatamente 11 dígitos.")
    if digits == digits[0] * 11:
        raise ValueError("Sequência repetida não é um CPF válido.")
    nums = [int(c) for c in digits]
    s1 = sum(nums[i] * (10 - i) for i in range(9))
    d1 = (s1 * 10) % 11
    if d1 == 10:
        d1 = 0
    s2 = sum(nums[i] * (11 - i) for i in range(10))
    d2 = (s2 * 10) % 11
    if d2 == 10:
        d2 = 0
    if nums[9] != d1 or nums[10] != d2:
        raise ValueError("Os dígitos verificadores não conferem.")
    return digits

def masked(cpf: str) -> str:
    return f"***.***.{cpf[6:9]}-**"

def build_report(cpf: str) -> dict:
    return {
        "executado_em_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "cpf_mascarado": masked(cpf),
        "validacao_formato_e_digitos": "válido",
        "consultas_externas_realizadas": False,
        "observacao": (
            "Este programa apenas validou localmente os dígitos do CPF e listou "
            "portais oficiais. Não confirma titularidade nem situação cadastral."
        ),
        "fontes_oficiais": OFFICIAL_SOURCES,
    }

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Valida localmente um CPF e lista portais oficiais para consulta própria."
    )
    parser.add_argument("--cpf", help="CPF para validação local. Evite passá-lo na linha de comando, pois pode ficar no histórico.")
    parser.add_argument("--sem-relatorio", action="store_true", help="Não salvar relatório JSON.")
    args = parser.parse_args()
    setup_logging()

    try:
        raw = args.cpf if args.cpf else getpass.getpass("Digite seu CPF (entrada oculta): ")
        cpf = normalize_cpf(raw)
    except (ValueError, KeyboardInterrupt) as exc:
        logging.error("%s", exc if isinstance(exc, ValueError) else "Execução cancelada.")
        return 2

    logging.info("Validação local concluída para %s.", masked(cpf))
    print("\nCPF: formato e dígitos verificadores válidos.")
    print("Atenção: isso não comprova titularidade nem confirma a situação cadastral.\n")
    print("Fontes oficiais para você autenticar-se e consultar seus próprios dados:")
    for i, item in enumerate(OFFICIAL_SOURCES, 1):
        parsed = urlparse(item["url"])
        if parsed.scheme != "https" or not parsed.netloc.endswith(("gov.br", "bcb.gov.br")):
            logging.error("Fonte não aprovada pela validação de domínio: %s", item["url"])
            continue
        print(f"\n{i}. {item['name']}\n   {item['purpose']}\n   {item['url']}")

    print("\nPrivacidade: o CPF não foi enviado a nenhum site nem incluído no relatório.")
    if not args.sem_relatorio:
        REPORT_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
        report_path = REPORT_DIR / (dt.datetime.now().strftime("%Y%m%d_%H%M%S") + ".json")
        report_path.write_text(
            json.dumps(build_report(cpf), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        try:
            report_path.chmod(0o600)
        except OSError:
            pass
        logging.info("Relatório salvo em %s.", report_path)
    logging.info("Nenhuma consulta externa foi executada.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
