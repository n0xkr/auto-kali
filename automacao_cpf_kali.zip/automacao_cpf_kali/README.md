# Automação local de CPF — Kali Linux / VPS / Docker

## O que faz
- Valida localmente o formato e os dígitos verificadores de um CPF.
- Mostra links de portais oficiais para que o próprio titular entre e consulte seus dados.
- Gera um relatório JSON com CPF mascarado; não salva o número completo.
- Registra a execução em `execucao.log`.

## O que não faz
- Não consulta automaticamente bases de dados.
- Não confirma titularidade nem situação cadastral do CPF.
- Não envia o CPF a sites, mecanismos de busca ou APIs.
- Não contorna login, CAPTCHA, autorização ou controles de acesso.

## Requisitos
- Python 3.10 ou superior.
- Nenhuma biblioteca de terceiros; não é necessário `pip install`.
- Para Docker, o contêiner precisa permitir executar Python e gravar arquivos no diretório do projeto.

## Execução
Na VPS, entre na pasta extraída e execute:

```bash
chmod +x executar.sh
./executar.sh
```

O CPF será solicitado com entrada oculta. Evite passar o CPF como argumento (`--cpf`), pois argumentos podem aparecer no histórico ou na lista de processos.

Para não gravar um relatório:
```bash
./executar.sh --sem-relatorio
```

## Instalação na VPS
Extraia o pacote numa pasta da sua conta, por exemplo `~/automacao_cpf`, e execute os comandos acima. Não use `sudo` salvo se houver uma necessidade administrativa específica. Em contêineres efêmeros, os arquivos podem desaparecer quando o contêiner for recriado; use um volume persistente se precisar preservar os relatórios.

## Fontes oficiais listadas
- Receita Federal: https://www.gov.br/receitafederal/pt-br/assuntos/meu-cpf
- Portal Gov.br: https://www.gov.br/
- Banco Central — Registrato: https://registrato.bcb.gov.br/
- Meu INSS: https://meu.inss.gov.br/

A disponibilidade e os requisitos de cada serviço são definidos pelo respectivo órgão e podem mudar. Faça a autenticação somente no domínio oficial e não compartilhe senha ou código de acesso com scripts.

## Segurança
Os relatórios contêm apenas CPF mascarado. Proteja a pasta e os logs, especialmente em VPS compartilhadas. Não coloque CPFs reais em tickets, repositórios públicos ou logs de shell.
