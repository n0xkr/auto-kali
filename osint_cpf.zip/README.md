# OSINT CPF Automation

Automação em Python configurada para consulta do CPF `03880063079` em ambiente Kali Linux / Docker / VPS Hostinger.

## Como baixar e executar no seu terminal via curl/wget

```bash
curl -L -o osint_cpf.zip "URL_DO_SEU_ZIP_NO_GITHUB"
unzip osint_cpf.zip
cd osint_cpf
chmod +x executar.sh
./executar.sh
```
