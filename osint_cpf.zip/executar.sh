#!/usr/bin/env bash
set -e

echo "[*] Verificando ambiente Kali Linux..."

if ! command -v python3 &> /dev/null; then
    echo "[!] Python3 não encontrado. Instalando..."
    apt-get update && apt-get install -y python3 python3-pip python3-venv
fi

if [ ! -d "venv" ]; then
    echo "[*] Criando ambiente virtual Python (venv)..."
    python3 -m venv venv
fi

echo "[*] Instalando dependências (requirements.txt)..."
./venv/bin/pip install --upgrade pip --quiet
./venv/bin/pip install -r requirements.txt --quiet

echo "[*] Executando script de pesquisa para o CPF 03880063079..."
./venv/bin/python3 consulta_cpf.py

echo ""
read -p "Pressione [ENTER] para fechar o terminal..."
